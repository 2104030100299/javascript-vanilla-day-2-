
<html>
	<head>
		
		<title>Demo Javascript Vanilla - JS</title>
		
		<style type="text/css">
			body{background-color:Green;}
			#D1{background-color:Red;height:300px;width:300px;}
		</style>
		
		<script type="text/javascript">
			function alertFun(){
				alert('Hello Tarannum');
			}
			
			function confirmFun(){
				if(confirm("Are you sure..??"))
				{
					alert("YESSSSS");
				}
				else
				{
					alert("NOOOOO");
				}
			}
			
			function promptFun(){
				var FirstName=prompt("Enter First Name Here..");
				var MiddleName=prompt("Enter Middle Name Here..");
				var LastName=prompt("Enter Last Name Here..");
				alert(FirstName +" "+MiddleName+" "+LastName);
			}
			
			function bodyBGChangeToYellow(){
				document.body.style.backgroundColor="Yellow";
			}
			
			function bodyBGChangeToText(){
				document.body.style.backgroundColor=prompt("Enter Background Color Here..");
			}
			
			function colorPickerBodyBG(){
				document.body.style.backgroundColor=document.getElementById("CP").value;
			}
			
			function yellowBGDiv(){
				document.getElementById("D1").style.backgroundColor="Yellow";
			}
			
			function divBGChangeToText(){
				document.getElementById("D1").style.backgroundColor=prompt("Enter Background Color Here..");
			}
			
			function colorPickerDivBG(){
				document.getElementById("D1").style.backgroundColor=document.getElementById("CP1").value;
			}
			
		</script>
		
		<script src="scripts/demo.js" type="text/javascript"></script>
		
	</head>
	<body>
		
		<div id="D1">
			Disha Bhavsar
		</div><hr/>
		
		<input type="button" value="Alert Inline" onclick="alert('Hello Tarannum')" />
		<input type="button" value="Alert Internal" onclick="alertFun()" />
		<input type="button" value="Alert External" onclick="alertFunEx()" /><hr/>
		
		<input type="button" value="Confirm Inline" onclick="confirm('Are You Sure..??')" />
		<input type="button" value="Confirm Internal" onclick="confirmFun()"/>
		<input type="button" value="Confirm External" onclick="confirmFunEx()"/><hr/>
		
		<input type="button" value="Prompt Inline" onclick="prompt('Enter First Name')"/>
		<input type="button" value="Prompt Internal" onclick="promptFun()"/>
		<input type="button" value="Prompt External" onclick="promptFunEx()"/><hr/>
		
		<input type="button" value="Yellow Body Background" onclick="bodyBGChangeToYellow()"/><hr/>
		<input type="button" value="Text Backgrond Color To Body" onclick="bodyBGChangeToText()"/><hr/>
		<input type="color" id="CP" onchange="colorPickerBodyBG()"/><hr/>
		
		<input type="button" value="Yellow Div Background" onclick="yellowBGDiv()"/><hr/>
		<input type="button" value="Text Backgrond Color To Div" onclick="divBGChangeToText()"/><hr/>
		<input type="color" id="CP1" onchange="colorPickerDivBG()" /><hr/>
	</body>
</html>